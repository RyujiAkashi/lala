package com.anastacio.draw.command;

import com.anastacio.drawfx.command.Command;
import com.anastacio.drawfx.model.Shape;
import com.anastacio.drawfx.service.AppService;

import java.awt.*;

public class ResizeShapeCommand implements Command {
    private final AppService appService;
    private final Shape shape;
    private final Point oldLocation;
    private final Point oldEnd;
    private final Point newLocation;
    private final Point newEnd;

    public ResizeShapeCommand(AppService appService, Shape shape, Point newLocation, Point newEnd) {
        this.appService = appService;
        this.shape = shape;
        this.oldLocation = new Point(shape.getLocation());
        this.oldEnd = new Point(shape.getEnd());
        this.newLocation = newLocation;
        this.newEnd = newEnd;
    }

    @Override
    public void execute() {
        shape.setLocation(newLocation);
        shape.setEnd(newEnd);
        appService.repaint();
    }

    @Override
    public void undo() {
        shape.setLocation(oldLocation);
        shape.setEnd(oldEnd);
        appService.repaint();
    }

    @Override
    public void redo() {
        shape.setLocation(newLocation);
        shape.setEnd(newEnd);
        appService.repaint();
    }
}
