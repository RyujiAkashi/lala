package com.anastacio.draw.command;

import com.anastacio.drawfx.command.Command;
import com.anastacio.drawfx.service.AppService;

import java.awt.*;

public class SetFillCommand implements Command {
    private final AppService appService;
    private final Color newFill;
    private Color oldFill;

    public SetFillCommand(AppService appService, Color newFill) {
        this.appService = appService;
        this.newFill = newFill;
    }

    @Override
    public void execute() {
        oldFill = appService.getFill();
        appService.setFill(newFill);
        appService.repaint();
    }

    @Override
    public void undo() {
        appService.setFill(oldFill);
        appService.repaint();
    }

    @Override
    public void redo() {
        appService.setFill(newFill);
        appService.repaint();
    }
}
