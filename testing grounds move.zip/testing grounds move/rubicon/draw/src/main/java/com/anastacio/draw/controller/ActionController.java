package com.anastacio.draw.controller;

import com.anastacio.draw.command.DeleteShapeCommand;
import com.anastacio.draw.command.SetColorCommand;
import com.anastacio.draw.command.SetFillCommand;
import com.anastacio.draw.command.SetShapeModeCommand;
import com.anastacio.draw.command.SetDrawModeCommand;
import com.anastacio.drawfx.ActionCommand;
import com.anastacio.drawfx.DrawMode;
import com.anastacio.drawfx.ShapeMode;
import com.anastacio.drawfx.command.CommandService;
import com.anastacio.drawfx.model.Drawing;
import com.anastacio.drawfx.model.Shape;
import com.anastacio.drawfx.service.AppService;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class ActionController implements ActionListener {
    private final AppService appService;
    private final Component parentForDialogs;
    private DrawingController drawingController;

    private final List<AbstractButton> undoControls = new ArrayList<>();
    private final List<AbstractButton> redoControls = new ArrayList<>();

    public ActionController(AppService appService, Component parentForDialogs) {
        this.appService = appService;
        this.parentForDialogs = parentForDialogs;
    }

    public void setDrawingController(DrawingController controller) {
        this.drawingController = controller;
    }

    public void wireUndoRedo(AbstractButton undo, AbstractButton redo) {
        if (undo != null) undoControls.add(undo);
        if (redo != null) redoControls.add(redo);
        refreshEnablement();
    }

    public void markNewCommand() {
        refreshEnablement();
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        String cmd = e.getActionCommand();

        switch (cmd) {
            case ActionCommand.UNDO:
                CommandService.undo();
                refreshEnablement();
                appService.repaint();
                return;

            case ActionCommand.REDO:
                CommandService.redo();
                refreshEnablement();
                appService.repaint();
                return;

            case ActionCommand.LINE:
                CommandService.ExecuteCommand(new SetShapeModeCommand(appService, ShapeMode.Line));
                CommandService.ExecuteCommand(new SetDrawModeCommand(appService, DrawMode.Idle));
                if (drawingController != null) {
                    drawingController.clearSelection();
                }
                refreshEnablement();
                return;

            case ActionCommand.RECT:
                CommandService.ExecuteCommand(new SetShapeModeCommand(appService, ShapeMode.Rectangle));
                CommandService.ExecuteCommand(new SetDrawModeCommand(appService, DrawMode.Idle));
                if (drawingController != null) {
                    drawingController.clearSelection();
                }
                refreshEnablement();
                return;

            case ActionCommand.ELLIPSE:
                CommandService.ExecuteCommand(new SetShapeModeCommand(appService, ShapeMode.Ellipse));
                CommandService.ExecuteCommand(new SetDrawModeCommand(appService, DrawMode.Idle));
                if (drawingController != null) {
                    drawingController.clearSelection();
                }
                refreshEnablement();
                return;

            case ActionCommand.STROKE: {
                Color selected = JColorChooser.showDialog(parentForDialogs, "Choose stroke color", appService.getColor());
                if (selected != null) {
                    CommandService.ExecuteCommand(new SetColorCommand(appService, selected));
                    refreshEnablement();
                }
                appService.repaint();
                return;
            }

            case ActionCommand.FILL: {
                Color selected = JColorChooser.showDialog(parentForDialogs, "Choose fill color", appService.getFill());
                if (selected != null) {
                    CommandService.ExecuteCommand(new SetFillCommand(appService, selected));
                    refreshEnablement();
                }
                appService.repaint();
                return;
            }

            case ActionCommand.SELECT:
                CommandService.ExecuteCommand(new SetDrawModeCommand(appService, DrawMode.Select));
                refreshEnablement();
                return;

            case ActionCommand.DELETE:
                deleteSelectedOrTopShape();
                refreshEnablement();
                return;
        }
    }

    private void deleteSelectedOrTopShape() {
        Object model = appService.getModel();
        if (model instanceof Drawing) {
            Drawing drawing = (Drawing) model;
            Shape shapeToDelete = null;

            if (drawingController != null && drawingController.getSelectedShape() != null) {
                shapeToDelete = drawingController.getSelectedShape();
                drawingController.clearSelection();
            } else if (!drawing.getShapes().isEmpty()) {
                shapeToDelete = drawing.getShapes().get(drawing.getShapes().size() - 1);
            }

            if (shapeToDelete != null) {
                CommandService.ExecuteCommand(new DeleteShapeCommand(appService, shapeToDelete));
                appService.repaint();
                refreshEnablement();
            }
        }
    }

    public void afterShapeMutatingCommand() {
        refreshEnablement();
    }

    public void refreshEnablement() {
        boolean canUndo = CommandService.canUndo();
        boolean canRedo = CommandService.canRedo();

        for (AbstractButton undo : undoControls) {
            undo.setEnabled(canUndo);
        }
        for (AbstractButton redo : redoControls) {
            redo.setEnabled(canRedo);
        }
    }
}
