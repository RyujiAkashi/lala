package com.anastacio.draw.controller;

import com.anastacio.draw.command.AddShapeCommand;
import com.anastacio.draw.command.MoveShapeCommand;
import com.anastacio.draw.command.ResizeShapeCommand;
import com.anastacio.draw.model.Ellipse;
import com.anastacio.draw.model.Line;
import com.anastacio.draw.model.Rectangle;
import com.anastacio.draw.view.DrawingView;
import com.anastacio.drawfx.DrawMode;
import com.anastacio.drawfx.SelectionMode;
import com.anastacio.drawfx.command.CommandService;
import com.anastacio.drawfx.model.Drawing;
import com.anastacio.drawfx.model.Shape;
import com.anastacio.drawfx.service.AppService;
import com.anastacio.drawfx.service.SearchService;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

public class DrawingController implements MouseListener, MouseMotionListener {
    private final DrawingView drawingView;
    private final AppService appService;
    private final ActionController actionController;
    private final SearchService searchService;

    private boolean dragging = false;
    private Point dragPoint;

    private Shape currentShape;
    private Shape selectedShape;
    private SelectionMode selectionMode;
    private Point anchorPoint;
    private Point originalLocation;
    private Point originalEnd;
    private Point selectedShapeOffset;

    public DrawingController(AppService appService, DrawingView drawingView, ActionController actionController){
        this.appService = appService;
        this.drawingView = drawingView;
        this.actionController = actionController;
        this.searchService = new SearchService();
        drawingView.addMouseListener(this);
        drawingView.addMouseMotionListener(this);
        this.actionController.refreshEnablement();
    }

    public Shape getCurrentShape() {
        return currentShape;
    }

    public Shape getSelectedShape() {
        return selectedShape;
    }

    public void clearSelection() {
        selectedShape = null;
        selectionMode = SelectionMode.NONE;
        appService.repaint();
    }

    @Override
    public void mousePressed(MouseEvent e) {
        dragPoint = e.getPoint();
        DrawMode mode = appService.getDrawMode();

        if (mode == DrawMode.Select) {
            Drawing drawing = (Drawing) appService.getModel();
            Shape clickedShape = searchService.findShapeAt(drawing, dragPoint);

            if (clickedShape != null) {
                if (selectedShape == clickedShape) {
                    selectionMode = searchService.findHandleAt(selectedShape, dragPoint);
                    if (selectionMode != SelectionMode.NONE) {
                        anchorPoint = searchService.getAnchorPoint(selectedShape, selectionMode);
                        originalLocation = new Point(selectedShape.getLocation());
                        originalEnd = new Point(selectedShape.getEnd());
                        if (selectionMode == SelectionMode.MOVE) {
                            Point topLeft = getTopLeft(selectedShape);
                            selectedShapeOffset = new Point(dragPoint.x - topLeft.x, dragPoint.y - topLeft.y);
                        }
                        dragging = true;
                    }
                } else {
                    selectedShape = clickedShape;
                    selectionMode = SelectionMode.NONE;
                    appService.repaint();
                }
            } else {
                selectedShape = null;
                selectionMode = SelectionMode.NONE;
                appService.repaint();
            }
            return;
        }

        if (mode == DrawMode.Idle) {
            switch (appService.getShapeMode()){
                case Line:
                    currentShape = new Line(dragPoint, dragPoint);
                    break;
                case Rectangle:
                    currentShape = new Rectangle(dragPoint, dragPoint);
                    break;
                case Ellipse:
                    currentShape = new Ellipse(dragPoint, dragPoint);
                    break;
            }
            currentShape.setColor(appService.getColor());
            currentShape.setFill(appService.getFill());
            dragging = true;
            drawingView.repaint();
        }
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        if (!dragging) return;

        Point end = e.getPoint();
        DrawMode mode = appService.getDrawMode();

        if (mode == DrawMode.Select && selectedShape != null && selectionMode != SelectionMode.NONE) {
            Point newLocation = new Point(selectedShape.getLocation());
            Point newEnd = new Point(selectedShape.getEnd());

            selectedShape.setLocation(originalLocation);
            selectedShape.setEnd(originalEnd);

            if (selectionMode == SelectionMode.MOVE) {
                Point newTopLeft = new Point(end.x - selectedShapeOffset.x, end.y - selectedShapeOffset.y);
                int width = Math.abs(originalEnd.x - originalLocation.x);
                int height = Math.abs(originalEnd.y - originalLocation.y);
                newLocation = newTopLeft;
                newEnd = new Point(newTopLeft.x + width, newTopLeft.y + height);
                CommandService.ExecuteCommand(new MoveShapeCommand(appService, selectedShape, newLocation));
            } else {
                CommandService.ExecuteCommand(new ResizeShapeCommand(appService, selectedShape, newLocation, newEnd));
            }
            selectionMode = SelectionMode.NONE;
        } else if (mode == DrawMode.Idle && currentShape != null) {
            currentShape.setEnd(end);
            CommandService.ExecuteCommand(new AddShapeCommand(appService, currentShape));
            currentShape = null;
        }

        dragging = false;
        selectedShapeOffset = null;
        anchorPoint = null;

        appService.repaint();
        actionController.markNewCommand();
        actionController.afterShapeMutatingCommand();
    }

    @Override
    public void mouseDragged(MouseEvent e) {
        if (!dragging) return;

        Point p = e.getPoint();
        DrawMode mode = appService.getDrawMode();

        if (mode == DrawMode.Select && selectedShape != null && selectionMode != SelectionMode.NONE) {
            if (selectionMode == SelectionMode.MOVE) {
                Point newTopLeft = new Point(p.x - selectedShapeOffset.x, p.y - selectedShapeOffset.y);
                int width = Math.abs(originalEnd.x - originalLocation.x);
                int height = Math.abs(originalEnd.y - originalLocation.y);
                selectedShape.setLocation(newTopLeft);
                selectedShape.setEnd(new Point(newTopLeft.x + width, newTopLeft.y + height));
            } else {
                resizeShapeWithHandle(selectedShape, anchorPoint, p, selectionMode);
            }
            appService.repaint();
        } else if (mode == DrawMode.Idle && currentShape != null) {
            currentShape.setEnd(p);
            drawingView.repaint();
        }
    }

    private void resizeShapeWithHandle(Shape shape, Point anchor, Point drag, SelectionMode mode) {
        String shapeType = shape.getClass().getSimpleName();

        if (shapeType.equals("Line")) {
            if (mode == SelectionMode.START) {
                shape.setLocation(drag);
            } else if (mode == SelectionMode.END) {
                shape.setEnd(drag);
            }
        } else {
            int newX1 = anchor.x;
            int newY1 = anchor.y;
            int newX2 = drag.x;
            int newY2 = drag.y;

            switch (mode) {
                case TOP_LEFT:
                    newX1 = drag.x;
                    newY1 = drag.y;
                    newX2 = anchor.x;
                    newY2 = anchor.y;
                    break;
                case TOP:
                    newX1 = anchor.x;
                    newY1 = drag.y;
                    newX2 = Math.max(anchor.x + Math.abs(originalEnd.x - originalLocation.x), anchor.x);
                    newY2 = anchor.y;
                    break;
                case TOP_RIGHT:
                    newX1 = anchor.x;
                    newY1 = drag.y;
                    newX2 = drag.x;
                    newY2 = anchor.y;
                    break;
                case RIGHT:
                    newX1 = anchor.x;
                    newY1 = anchor.y;
                    newX2 = drag.x;
                    newY2 = Math.max(anchor.y + Math.abs(originalEnd.y - originalLocation.y), anchor.y);
                    break;
                case BOTTOM_RIGHT:
                    newX1 = anchor.x;
                    newY1 = anchor.y;
                    newX2 = drag.x;
                    newY2 = drag.y;
                    break;
                case BOTTOM:
                    newX1 = anchor.x;
                    newY1 = anchor.y;
                    newX2 = Math.max(anchor.x + Math.abs(originalEnd.x - originalLocation.x), anchor.x);
                    newY2 = drag.y;
                    break;
                case BOTTOM_LEFT:
                    newX1 = drag.x;
                    newY1 = anchor.y;
                    newX2 = anchor.x;
                    newY2 = drag.y;
                    break;
                case LEFT:
                    newX1 = drag.x;
                    newY1 = anchor.y;
                    newX2 = anchor.x;
                    newY2 = Math.max(anchor.y + Math.abs(originalEnd.y - originalLocation.y), anchor.y);
                    break;
            }

            int finalX1 = Math.min(newX1, newX2);
            int finalY1 = Math.min(newY1, newY2);
            int finalX2 = Math.max(newX1, newX2);
            int finalY2 = Math.max(newY1, newY2);

            shape.setLocation(new Point(finalX1, finalY1));
            shape.setEnd(new Point(finalX2, finalY2));
        }
    }

    private Point getTopLeft(Shape s) {
        return new Point(
                Math.min(s.getLocation().x, s.getEnd().x),
                Math.min(s.getLocation().y, s.getEnd().y)
        );
    }

    @Override public void mouseClicked(MouseEvent e) {}
    @Override public void mouseEntered(MouseEvent e) {}
    @Override public void mouseExited(MouseEvent e) {}
    @Override public void mouseMoved(MouseEvent e) {}
}
