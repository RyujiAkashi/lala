package com.anastacio.draw.model;

import com.anastacio.draw.service.EllipseRenderer;
import com.anastacio.drawfx.model.Shape;

import java.awt.*;

public class Ellipse extends Shape {
    public Ellipse(Point start, Point end){
        super(start);
        this.setEnd(end);
        this.setColor(Color.RED);
        this.setRendererService(new EllipseRenderer());
    }
}