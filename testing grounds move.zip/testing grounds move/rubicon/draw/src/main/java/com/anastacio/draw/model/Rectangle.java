package com.anastacio.draw.model;

import com.anastacio.draw.service.RectangleRendererService;
import com.anastacio.drawfx.model.Shape;

import java.awt.*;

public class Rectangle extends Shape {

    public Rectangle(Point start, Point end){
        super(start);
        this.setEnd(end);
        this.setColor(Color.RED);
        this.setRendererService(new RectangleRendererService());
    }
}
