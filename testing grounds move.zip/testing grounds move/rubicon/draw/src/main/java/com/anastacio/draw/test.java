package com.anastacio.draw;

public class test {
    public static void main(String[] args) {

        java.net.URL url = test.class.getResource("/com/anastacio/draw/view/images/undo.png");
        if (url == null) {
            System.out.println("Icon not found");
        } else {
            System.out.println("Icon found at: " + url);
        }
    }
}
