package com.anastacio.draw.view;

import com.anastacio.draw.controller.DrawingWindowController;
import com.anastacio.drawfx.service.AppService;

import javax.swing.*;

public class DrawingFrame extends JFrame {

    public DrawingFrame(AppService appService){
        DrawingWindowController drawingWindowController = new DrawingWindowController(appService);
        this.addWindowListener(drawingWindowController);
        this.addWindowFocusListener(drawingWindowController);
        this.addWindowStateListener(drawingWindowController);


    }
}
