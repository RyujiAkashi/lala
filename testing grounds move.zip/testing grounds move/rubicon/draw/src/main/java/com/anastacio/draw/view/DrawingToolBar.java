package com.anastacio.draw.view;

import com.anastacio.draw.controller.ActionController;
import com.anastacio.drawfx.ActionCommand;

import javax.swing.*;
import java.awt.*;
import java.net.URL;

public class DrawingToolBar extends JToolBar {


    private ImageIcon loadIcon(String name) {
        String path = "images/" + name;
        java.net.URL url = getClass().getResource(path);
        if (url == null) {
            System.err.println(" Icon not found: " + path);
            return new ImageIcon();
        }
        URL imageURL = DrawingToolBar.class.getResource(path);
        ImageIcon original = new ImageIcon(imageURL, name);
        Image scaled = original.getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH);
        return new ImageIcon(scaled);
    }


    public final JButton undoButton = new JButton(loadIcon("undo.png"));
    public final JButton redoButton = new JButton(loadIcon("redo.png"));

    public final JButton lineButton = new JButton(loadIcon("line.png"));
    public final JButton rectangleButton = new JButton(loadIcon("rectangle.png"));
    public final JButton ellipseButton = new JButton(loadIcon("ellipse.png"));

    public final JButton strokeButton = new JButton(loadIcon("color.png"));
    public final JButton fillButton = new JButton(loadIcon("fill.png"));

    public final JButton selectButton = new JButton(loadIcon("select.png"));

    public final JButton deleteButton = new JButton(loadIcon("delete.png"));

    public DrawingToolBar(ActionController actionController) {
        super("Tools");


        undoButton.setActionCommand(ActionCommand.UNDO);
        redoButton.setActionCommand(ActionCommand.REDO);

        lineButton.setActionCommand(ActionCommand.LINE);
        rectangleButton.setActionCommand(ActionCommand.RECT);
        ellipseButton.setActionCommand(ActionCommand.ELLIPSE);

        strokeButton.setActionCommand(ActionCommand.STROKE);
        fillButton.setActionCommand(ActionCommand.FILL);

        selectButton.setActionCommand(ActionCommand.SELECT);
        selectButton.setToolTipText("Select");

        deleteButton.setActionCommand(ActionCommand.DELETE);


        undoButton.addActionListener(actionController);
        redoButton.addActionListener(actionController);
        lineButton.addActionListener(actionController);
        rectangleButton.addActionListener(actionController);
        ellipseButton.addActionListener(actionController);
        strokeButton.addActionListener(actionController);
        fillButton.addActionListener(actionController);
        selectButton.addActionListener(actionController);
        deleteButton.addActionListener(actionController);


        add(undoButton);
        add(redoButton);
        addSeparator();
        add(lineButton);
        add(rectangleButton);
        add(ellipseButton);
        addSeparator();
        add(strokeButton);
        add(fillButton);
        addSeparator();
        add(selectButton);
        addSeparator();
        add(deleteButton);


        actionController.wireUndoRedo(undoButton, redoButton);
    }
}
