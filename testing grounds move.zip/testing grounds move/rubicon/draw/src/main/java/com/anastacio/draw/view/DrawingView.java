package com.anastacio.draw.view;

import com.anastacio.draw.controller.DrawingController;
import com.anastacio.drawfx.model.Drawing;
import com.anastacio.drawfx.model.Shape;
import com.anastacio.drawfx.service.AppService;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class DrawingView extends JPanel {

    private final AppService appService;
    private DrawingController controller;
    private static final int HANDLE_SIZE = 8;

    public DrawingView(AppService appService) {
        this.appService = appService;
        setBackground(Color.WHITE);
        setDoubleBuffered(true);
    }

    public void setController(DrawingController controller) {
        this.controller = controller;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        Drawing drawing = (Drawing) appService.getModel();
        List<Shape> shapes = drawing.getShapes();

        for (Shape shape : shapes) {
            shape.getRendererService().render(g, shape, false);
        }

        if (controller != null) {
            Shape preview = controller.getCurrentShape();
            if (preview != null) {
                preview.getRendererService().render(g, preview, true);
            }

            Shape selected = controller.getSelectedShape();
            if (selected != null) {
                drawHandles(g, selected);
            }
        }
    }

    private void drawHandles(Graphics g, Shape shape) {
        Graphics2D g2d = (Graphics2D) g;
        g2d.setColor(Color.BLACK);
        g2d.setStroke(new BasicStroke(1));

        String shapeType = shape.getClass().getSimpleName();

        if (shapeType.equals("Line")) {
            Point start = shape.getLocation();
            Point end = shape.getEnd();

            drawHandle(g2d, start.x, start.y);
            drawHandle(g2d, end.x, end.y);
        } else {
            int x1 = Math.min(shape.getLocation().x, shape.getEnd().x);
            int y1 = Math.min(shape.getLocation().y, shape.getEnd().y);
            int x2 = Math.max(shape.getLocation().x, shape.getEnd().x);
            int y2 = Math.max(shape.getLocation().y, shape.getEnd().y);
            int cx = (x1 + x2) / 2;
            int cy = (y1 + y2) / 2;

            drawHandle(g2d, x1, y1);
            drawHandle(g2d, cx, y1);
            drawHandle(g2d, x2, y1);
            drawHandle(g2d, x2, cy);
            drawHandle(g2d, x2, y2);
            drawHandle(g2d, cx, y2);
            drawHandle(g2d, x1, y2);
            drawHandle(g2d, x1, cy);

            g2d.setColor(new Color(0, 0, 255, 50));
            g2d.drawRect(x1, y1, x2 - x1, y2 - y1);
        }
    }

    private void drawHandle(Graphics2D g2d, int x, int y) {
        g2d.setColor(Color.WHITE);
        g2d.fillRect(x - HANDLE_SIZE / 2, y - HANDLE_SIZE / 2, HANDLE_SIZE, HANDLE_SIZE);
        g2d.setColor(Color.BLACK);
        g2d.drawRect(x - HANDLE_SIZE / 2, y - HANDLE_SIZE / 2, HANDLE_SIZE, HANDLE_SIZE);
    }
}
