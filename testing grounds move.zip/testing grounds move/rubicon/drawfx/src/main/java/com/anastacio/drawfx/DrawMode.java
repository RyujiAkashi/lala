package com.anastacio.drawfx;

public enum DrawMode {
    Idle,
    MousePressed,
    MouseReleased,
    Select
}
