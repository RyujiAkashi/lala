package com.anastacio.drawfx;

public enum SelectionMode {
    NONE,
    MOVE,
    TOP_LEFT,
    TOP,
    TOP_RIGHT,
    RIGHT,
    BOTTOM_RIGHT,
    BOTTOM,
    BOTTOM_LEFT,
    LEFT,
    START,
    END
}
