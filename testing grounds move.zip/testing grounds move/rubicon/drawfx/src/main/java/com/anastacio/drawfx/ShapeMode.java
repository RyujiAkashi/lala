package com.anastacio.drawfx;

public enum ShapeMode {
    Line,
    Rectangle,
    Ellipse,
}
