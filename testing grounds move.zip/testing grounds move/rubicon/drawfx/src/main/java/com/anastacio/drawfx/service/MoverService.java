package com.anastacio.drawfx.service;

import com.anastacio.drawfx.model.Shape;

import java.awt.*;

public final class MoverService {
    public void  move(Shape shape, Point newLoc){
        shape.setLocation( newLoc);
    }
}
