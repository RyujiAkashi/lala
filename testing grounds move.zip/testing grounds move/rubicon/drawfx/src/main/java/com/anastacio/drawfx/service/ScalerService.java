package com.anastacio.drawfx.service;

import com.anastacio.drawfx.model.Shape;

import java.awt.*;

public final class  ScalerService {
    void scale(Shape shape, Point newEnd){
        shape.setEnd(newEnd);
    }
}
