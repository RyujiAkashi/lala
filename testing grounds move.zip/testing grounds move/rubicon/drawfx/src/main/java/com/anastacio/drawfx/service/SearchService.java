package com.anastacio.drawfx.service;

import com.anastacio.drawfx.SelectionMode;
import com.anastacio.drawfx.model.Drawing;
import com.anastacio.drawfx.model.Shape;

import java.awt.*;
import java.util.List;

public class SearchService {
    private static final int HANDLE_SIZE = 8;
    private static final int SEARCH_RADIUS = 10;

    public Shape findShapeAt(Drawing drawing, Point p) {
        List<Shape> shapes = drawing.getShapes();
        for (int i = shapes.size() - 1; i >= 0; i--) {
            Shape s = shapes.get(i);
            if (getBounds(s).contains(p)) {
                return s;
            }
        }
        return null;
    }

    public SelectionMode findHandleAt(Shape shape, Point p) {
        if (shape == null) return SelectionMode.NONE;

        String shapeType = shape.getClass().getSimpleName();

        if (shapeType.equals("Line")) {
            Point start = shape.getLocation();
            Point end = shape.getEnd();

            if (isNearPoint(p, start, SEARCH_RADIUS)) {
                return SelectionMode.START;
            }
            if (isNearPoint(p, end, SEARCH_RADIUS)) {
                return SelectionMode.END;
            }
        } else {
            int x1 = Math.min(shape.getLocation().x, shape.getEnd().x);
            int y1 = Math.min(shape.getLocation().y, shape.getEnd().y);
            int x2 = Math.max(shape.getLocation().x, shape.getEnd().x);
            int y2 = Math.max(shape.getLocation().y, shape.getEnd().y);
            int cx = (x1 + x2) / 2;
            int cy = (y1 + y2) / 2;

            if (isNearPoint(p, new Point(x1, y1), SEARCH_RADIUS)) {
                return SelectionMode.TOP_LEFT;
            }
            if (isNearPoint(p, new Point(cx, y1), SEARCH_RADIUS)) {
                return SelectionMode.TOP;
            }
            if (isNearPoint(p, new Point(x2, y1), SEARCH_RADIUS)) {
                return SelectionMode.TOP_RIGHT;
            }
            if (isNearPoint(p, new Point(x2, cy), SEARCH_RADIUS)) {
                return SelectionMode.RIGHT;
            }
            if (isNearPoint(p, new Point(x2, y2), SEARCH_RADIUS)) {
                return SelectionMode.BOTTOM_RIGHT;
            }
            if (isNearPoint(p, new Point(cx, y2), SEARCH_RADIUS)) {
                return SelectionMode.BOTTOM;
            }
            if (isNearPoint(p, new Point(x1, y2), SEARCH_RADIUS)) {
                return SelectionMode.BOTTOM_LEFT;
            }
            if (isNearPoint(p, new Point(x1, cy), SEARCH_RADIUS)) {
                return SelectionMode.LEFT;
            }
        }

        if (getBounds(shape).contains(p)) {
            return SelectionMode.MOVE;
        }

        return SelectionMode.NONE;
    }

    private boolean isNearPoint(Point p1, Point p2, int radius) {
        return p1.distance(p2) <= radius;
    }

    private Rectangle getBounds(Shape s) {
        int x = Math.min(s.getLocation().x, s.getEnd().x);
        int y = Math.min(s.getLocation().y, s.getEnd().y);
        int w = Math.abs(s.getEnd().x - s.getLocation().x);
        int h = Math.abs(s.getEnd().y - s.getLocation().y);
        return new Rectangle(x, y, w, h);
    }

    public Point getAnchorPoint(Shape shape, SelectionMode mode) {
        int x1 = Math.min(shape.getLocation().x, shape.getEnd().x);
        int y1 = Math.min(shape.getLocation().y, shape.getEnd().y);
        int x2 = Math.max(shape.getLocation().x, shape.getEnd().x);
        int y2 = Math.max(shape.getLocation().y, shape.getEnd().y);

        switch (mode) {
            case TOP_LEFT: return new Point(x2, y2);
            case TOP: return new Point(x1, y2);
            case TOP_RIGHT: return new Point(x1, y2);
            case RIGHT: return new Point(x1, y1);
            case BOTTOM_RIGHT: return new Point(x1, y1);
            case BOTTOM: return new Point(x1, y1);
            case BOTTOM_LEFT: return new Point(x2, y1);
            case LEFT: return new Point(x2, y1);
            case START: return shape.getEnd();
            case END: return shape.getLocation();
            default: return null;
        }
    }
}
